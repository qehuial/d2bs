	
	기존에 사용하시던 분들은
	d2bs\kolbot\libs\common폴더 덮어씌우시고
	사용하시는 캐릭터 이니를 수정해 주셔야 합니다. 기존에 있던 내용을 조금 수정하셔야 합니다.
	
	
	-----------기존 내용------------
	
	/* 벨트 포션 설정
	 * 힐링포션 ("hp"), 마나포션 ("mp"), 활력포션 ("rv")
	 */
	Config.BeltColumn[0] = "hp";
	Config.BeltColumn[1] = "mp";
	Config.BeltColumn[2] = "rv";
	Config.BeltColumn[3] = "rv";

	/* 포션이 일정수 미만으로 떨어지면 상점으로 사러감
	 * 활력포션은 살 수 없으므로 0으로 설정
	 */
	Config.MinColumn[0] = 2;
	Config.MinColumn[1] = 2;
	Config.MinColumn[2] = 0;
	Config.MinColumn[3] = 0;
	
	
	
	
	
	-----------수정할 내용------------
	
	아래 내용으로 교체해주시고 포탈은 4번으로 되어 있으나 번호로 입력하셔도 무방합니다.
	
	/* 벨트 포션 설정
	 * 힐링포션 ("hp"), 마나포션 ("mp"), 활력포션 ("rv"), 
	 * 포탈스크롤 TownPortal = true;, Config.BeltColumn[3] = "tsc";
	 */
	Config.TownPortal = true;
	Config.BeltColumn[0] = "hp";
	Config.BeltColumn[1] = "mp";
	Config.BeltColumn[2] = "rv";
	Config.BeltColumn[3] = "tsc";

	/* 포션이 일정수 미만으로 떨어지면 상점으로 사러감
	 * 활력포션은 살 수 없으므로 0으로 설정
	 */
	Config.MinColumn[0] = 2;
	Config.MinColumn[1] = 2;
	Config.MinColumn[2] = 0;
	Config.MinColumn[3] = 4;